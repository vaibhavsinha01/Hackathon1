import os
import pandas as pd

# Load the data
data = pd.read_csv(r'C:\Users\Vaibhav\Desktop\hackathon2\data\storage\BankChurners.csv')

# Filter old customers and save to CSV
old_customers_df = data[data['Attrition_Flag'] == 0]
old_customers_df.to_csv(os.path.join(r'C:\Users\Vaibhav\Desktop\hackathon2\data\report', 'Old_Customers.csv'))

# Columns to analyze
items = data[["Gender", "Dependent_count", "Education_Level", "Marital_Status", "Income_Category", "Card_Category", 
              "Total_Relationship_Count", "Months_Inactive_12_mon", "Contacts_Count_12_mon"]]

# Iterate through columns and calculate the mode for each column
for item in items.columns:
    mode_value = data[item].mode()[0]  # Get the mode for the column
    print(f'Mode of {item}: {mode_value}')